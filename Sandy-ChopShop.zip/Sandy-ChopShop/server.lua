print('\n\n- - - - - - - - - - - - - - - - - - - - - -\n^7[^$ANDY $HORE$^7] ^7[^CUSTOM MAPP CREATED BY MCNASTTY#1922^7] ^CHOP $HOP.^0\n- - - - - - - - - - - - - - - - - - - - - -\n')
           
      