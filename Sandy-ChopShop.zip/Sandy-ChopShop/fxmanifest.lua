name "Chop $hop"
author "McNastty6699"
description "SANDY CHOPSHOP V1.0"

fx_version 'cerulean'
game 'gta5'

this_is_a_map 'yes'

server_scripts {
	'server.lua',
}